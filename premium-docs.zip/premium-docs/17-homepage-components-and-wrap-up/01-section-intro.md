# Section Intro

Alright guys, we're just about there. There are a couple components that I want to add to the homepage to make it look a bit more professional.

First we will add an Icon Boxes component. This will just be some cards with some icons and some common text you see in an ecommerce website like money back guarantee and 24/7 support.

Then we will create a countdown timer like you often see on sites like this. We will set it to something like 5 days.

Then we'll go ahead and wrap things up for now and talk about where to go from here.