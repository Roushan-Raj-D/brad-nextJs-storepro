# Section Intro

In this section, we're going to take care of two things. First, the user managment in the admin aream then the admin search functionality.

So we'll create an action and then use that action within a page to get and display users.

We'll also add the ability to delete users using the same delete-dialog component that we used for orders and products.

We want to be able to edit some of the user info, so we'll add that.

Then once the users are done, we'll move to the admin search. If you notice, there is a search in the header on the products, orders and users pages. What I want is if they search while on the products page, then it searches the products. Then we'll do the same for the orders and users as well.

