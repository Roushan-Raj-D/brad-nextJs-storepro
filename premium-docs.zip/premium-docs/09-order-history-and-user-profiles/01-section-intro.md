# Section Intro

Now we are going to create the user area. This will be where users can see their orders as well as update their profile.

We'll start with the user area layout and the menu, which will have the view orders and update profile links.

We'll create the user orders page and the action to get all of their orders and then add pagination ability to it.

The user profile will be really simple, but I want to let the user change their name so we will first create an action to update their profile. 

Then we'll create the update user profile form. 

Overall, this should be a pretty easy section to get through.